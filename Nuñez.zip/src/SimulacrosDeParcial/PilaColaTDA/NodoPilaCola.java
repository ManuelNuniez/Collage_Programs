package PilaColaTDA;

public class NodoPilaCola {
    int info;
    NodoPilaCola sig;
}
