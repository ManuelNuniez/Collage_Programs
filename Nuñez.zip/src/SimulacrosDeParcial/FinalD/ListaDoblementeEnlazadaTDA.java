package FinalD;

public interface ListaDoblementeEnlazadaTDA {

    void InicializarLista ();
    void Agregar(int x);
    void Eliminar(int x);
    int PrimerElemnto();
    int UltimoElemento();
    boolean ListaVacia();
    void Imprimir();
    
}
