package FinalD;

public class NodoDoble {
    int val;
    NodoDoble sig;
    NodoDoble prev;
}
