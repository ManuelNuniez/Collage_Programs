package EjercicioAlumnosID;
import Lista.ListaTDA;// SI
public class NodoAlumnos {
    ListaTDA info;
    int indice;
    int Clave;
    NodoAlumnos sig;
}
