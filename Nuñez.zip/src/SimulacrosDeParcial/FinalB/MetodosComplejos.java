package FinalB;

public class MetodosComplejos {
    public static void ImprimirComplejo(NumeroComplejoTDA ab){
        System.out.printf("%.2f + %.2fi\n",ab.real(),ab.imaginario());
    }

}
