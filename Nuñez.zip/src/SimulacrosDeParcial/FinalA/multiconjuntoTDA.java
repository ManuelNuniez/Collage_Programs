package FinalA;

public interface multiconjuntoTDA {
    void inicializarMulticonjunto();
    //TDA inicializado
    void agregar(int x);
    //TDA inicializado y no vacio
    void sacar(int x);
    // TDA inicializado y no vacio
    int multiplicidad(int x);
    // TDA inicializado
    boolean multiconjuntojuntoVacio();
    // Tda inicializado y no vacio
    int elegir();
}
