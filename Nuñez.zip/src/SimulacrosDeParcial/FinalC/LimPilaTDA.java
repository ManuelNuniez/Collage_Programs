package FinalC;

public interface LimPilaTDA {
    void InicializarPila(int x);
    void Apilar(int x);
    void Desapilar();
    boolean PilaVacia();
    boolean PilaLlena();
    int Capacidad();
    int Tope();
}
