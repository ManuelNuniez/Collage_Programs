package Arbol;

public class NodoABB {
    int Info;
    ArbolBBTDA HijoIzq;
    ArbolBBTDA HijoDer;

}
