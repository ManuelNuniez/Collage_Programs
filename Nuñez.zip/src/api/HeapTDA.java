package api;

public interface HeapTDA {
    public void InicializarHeap();
    public void AgregarH(int valor);
    public void SacarH();
    boolean HeapVacio();
    int PrimerValor();

}
