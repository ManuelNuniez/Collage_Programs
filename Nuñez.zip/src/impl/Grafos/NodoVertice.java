package impl.Grafos;

public class NodoVertice {
    int valor;
    NodoArista arista;
    NodoVertice sigNodo;
}
