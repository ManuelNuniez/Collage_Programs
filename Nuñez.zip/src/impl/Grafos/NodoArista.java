package impl.Grafos;

public class NodoArista {
    int peso;
    NodoVertice nodoDestino;
    NodoArista sigArista;

}
