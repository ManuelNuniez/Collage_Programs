package impl;

public class ValPrio {
    public int valor;
    public int prioridad;
}
