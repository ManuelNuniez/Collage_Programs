package impl;

public class NodoPrioridad {
    int info;
    int prio;
    NodoPrioridad sig;
}
