package ExamenParcial;

public class NodoExamen {
    int Reserva;
    int pasajero;
    int vuelo;
    int asiento;
    int fechaDeVuelo;
    NodoExamen sig;
}
