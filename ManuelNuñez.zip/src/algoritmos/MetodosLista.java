package algoritmos;

public class MetodosLista {

}
