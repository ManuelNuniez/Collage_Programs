package Lista;

public class NodoLista {
    int info;
    NodoLista sig;

}
