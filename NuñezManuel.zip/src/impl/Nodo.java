package impl;

public class Nodo {
    int info;
    Nodo sig;

}
