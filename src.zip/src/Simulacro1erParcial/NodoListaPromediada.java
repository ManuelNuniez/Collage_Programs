package Simulacro1erParcial;

public class NodoListaPromediada {
    int info;
    NodoListaPromediada sig;
}
