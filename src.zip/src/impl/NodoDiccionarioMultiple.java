package impl;

import api.ConjuntoTDA;

public class NodoDiccionarioMultiple {
    int Clave;
    ConjuntoTDA valores;
    NodoDiccionarioMultiple sig;

}
