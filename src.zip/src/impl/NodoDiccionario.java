package impl;

public class NodoDiccionario {
    int ClaveN;
    int ValorN;
    NodoDiccionario sig;

}
