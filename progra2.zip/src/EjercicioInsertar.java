public class EjercicioInsertar {  
        
    public void Insertar(int[] v, int cont, int n_insertar, int pos_insertar){
        while (cont == pos_insertar){
            v[cont] == v[cont - 1];
            cont--;
        }
        v[pos_insertar]= n_insertar;

    }  
    public static void main(String[] args) throws Exception {    
        int cont = 0;
        int[] v = new int[10];

        for (int i = 0; i <= 6; i++) {
            v[i] = i;
            cont++;
        }
        System.out.println(v);

        Insertar(v, cont, 6, 3);
        System.out.println("el numero fue insertado "  + v);
    }
}